<?php

    session_start();
    require_once('../../initialize.php');
    require_once('../../config.php');
    
    $num = $_POST["userpara"];    
    $strFuncType = $num[0];    
    //$strFuncType = "funGetData_BarChart2";
      
    //----------- Set TimeZone ----------------------------
    date_default_timezone_set('Asia/Kolkata');
    $strServerDateTime = date("Y-m-d H:i:s");    
    //----------- Declare Variables -----------------------  
    $i = 0; 
    $j = 0;     
    $Status_ary     = array();
    $ReturnData_ary = array();
    //$ReturnData_ary[0][0]  = "NA";
    $strText    = "";
    $ReturnData_ary[0][0] = "NA"; 
    //$ReturnData_ary[0][1] = "NA";
    //$ReturnData_ary[1][0] = "NA"; 
    //$ReturnData_ary[1][1] = "NA";
    
    $intWoState = 4;
    
    if($strFuncType === "funGetData_PieChart3") //------------- funUpdateEventLog --------------------
    {
        $strStarDate    = $num[1];
        $strEndDate     = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
         
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND McCategory = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
                $whereClause .= " AND ClosedFaultType  = '" . $strStatus . "'";          
        } 
        try 
        {   
            $sqlString = "
                SELECT
                CreatedDepartment, COUNT(*) AS Total_Count
                FROM 
                    tblwo_event 
                WHERE " . $whereClause." GROUP BY CreatedDepartment";
            
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate); 
            $stmt->bindParam(':edate', $strEndDate); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['CreatedDepartment'];
                $ReturnData_ary[1][$i] = $row['Total_Count']; 
                
                               
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = $sqlString;            //"Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;
    }

    else if($strFuncType === "funGetData_PieChart4") //------------- funUpdateEventLog --------------------
    {
        
        $strStarDate       = $num[1];
        $strEndDate        = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
         
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND Site = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
            $whereClause .= " AND IssueType  = '" . $strStatus . "'";          
        } 
        
        try 
        {    
            $sqlString = "
                SELECT 
                    Location,
                    SUM(TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime)) AS Time_Duration 
                FROM 
                    tblwo_event 
                WHERE " . $whereClause." GROUP BY Location";
                

            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate); 
            $stmt->bindParam(':edate', $strEndDate); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['Location'];
                $ReturnData_ary[1][$i] = number_format($row['Time_Duration'] / 60, 1);
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = "Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;
    }    
    else if($strFuncType === "funGetData_PieChartNew1") //------------- funUpdateEventLog --------------------
    {
        $strStarDate    = $num[1];
        $strEndDate     = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
         
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND McCategory = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
            $whereClause .= " AND ClosedFaultType  = '" . $strStatus . "'";          
        } 
        try 
        {   
            $sqlString = "
                SELECT 
                    CreatedDepartment, 
                    SUM(TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime)) AS Time_Duration 
                FROM 
                    tblwo_event 
               WHERE " . $whereClause." GROUP BY CreatedDepartment";
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate); 
            $stmt->bindParam(':edate', $strEndDate); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['CreatedDepartment'];
                $ReturnData_ary[1][$i] = number_format($row['Time_Duration'] / 60, 1);
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = $sqlString;            //"Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;
    }
    else if($strFuncType === "funGetData_PieChartNew2") //------------- funUpdateEventLog --------------------
    {
        $strStarDate    = $num[1];
        $strEndDate     = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
         
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND McCategory = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
            $whereClause .= " AND ClosedFaultType  = '" . $strStatus . "'";          
        } 
        try 
        {   
            $sqlString = "
                SELECT 
                    CreatedDepartment, 
                    SUM(TIMESTAMPDIFF(MINUTE, CreatedDateTime, RespondDateTime)) AS Time_Duration 
                FROM 
                    tblwo_event 
               WHERE " . $whereClause." GROUP BY CreatedDepartment";
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate); 
            $stmt->bindParam(':edate', $strEndDate); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['CreatedDepartment'];
                $ReturnData_ary[1][$i] = number_format($row['Time_Duration'] / 60, 1); 
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = $sqlString;            //"Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;
    }
    else if($strFuncType === "funGetData_BarChart1") //------------- funUpdateEventLog --------------------
    {   
        $strStarDate2   = $num[1];
        $strEndDate2    = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
         
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND Site = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
            $whereClause .= " AND IssueType  = '" . $strStatus . "'";          
        } 
        
        try 
        {    
            $sqlString = " 
                SELECT 
                Location,
                    SUM(CASE WHEN WoStatus = 'New' THEN TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime) ELSE 0 END) AS New_Count,
                    SUM(CASE WHEN WoStatus = 'Inprogress' THEN TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime) ELSE 0 END) AS Inprogress_Count,
                    SUM(CASE WHEN WoStatus = 'Closed' THEN TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime) ELSE 0 END) AS Closed_Count
                    
                FROM 
                    tblwo_event 
                WHERE " . $whereClause . 
                " GROUP BY 
                Location;";
            
            // echo $sqlString;
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate2); 
            $stmt->bindParam(':edate', $strEndDate2); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['Location'];
                $ReturnData_ary[1][$i] = number_format($row['New_Count'] / 60, 2); 
                $ReturnData_ary[2][$i] = number_format($row['Inprogress_Count'] / 60, 2); 
                $ReturnData_ary[3][$i] = number_format($row['Closed_Count'] / 60, 2);               
                 
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = "Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;

    }
    else if($strFuncType === "funGetData_BarChart2") //------------- funUpdateEventLog --------------------
    {
   
        $strStarDate2   = $num[1];
        $strEndDate2    = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
                
        //$strStarDate2   = '2024-06-22';
        //$strEndDate2    = '2024-06-28';
        //$strDepartment  = 'All';
        //$strCategory    = 'All';
        //$strStatus      = 'All';
        
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND McCategory = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
            $whereClause .= " AND ClosedFaultType  = '" . $strStatus . "'";          
        } 
        
        try 
        {            	 
            $sqlString = "
                
                SELECT 
                    CreatedDepartment, 
                    AVG(TIMESTAMPDIFF(MINUTE, CreatedDateTime, RespondDateTime)) AS Time_Duration 
                FROM 
                    tblwo_event 
               WHERE " . $whereClause." GROUP BY CreatedDepartment";
           
            
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate2); 
            $stmt->bindParam(':edate', $strEndDate2); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['CreatedDepartment'];
                $ReturnData_ary[1][$i] = number_format($row['Time_Duration'] / 60, 2);
                 
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = "Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;
    }
    else if($strFuncType === "funGetData_BarChart3") //------------- funUpdateEventLog --------------------
    {
        $strStarDate2   = $num[1];
        $strEndDate2    = $num[2];
        $strDepartment  = $num[3];
        $strCategory    = $num[4];
        $strStatus      = $num[5];
         
        $whereClause = "WorkOrderCategory = 'BreakDown' AND State < 6 AND ClosedDateTime IS NOT NULL AND DATE(CreatedDateTime) BETWEEN :sdate AND :edate";
                
        if ($strDepartment !== "All") {
            $whereClause .= " AND CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND McCategory = '" . $strCategory . "'";
        }  
        if ($strStatus !== "All") {
            $whereClause .= " AND ClosedFaultType  = '" . $strStatus . "'";          
        } 
        
        try 
        {            	 
            $sqlString = "                
            SELECT 
            MachineNo,
                SUM(CASE WHEN ClosedFaultType = 'Electrical' THEN TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime) ELSE 0 END) AS Electrical_Count,
                SUM(CASE WHEN ClosedFaultType = 'Mechanical' THEN TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime) ELSE 0 END) AS Mechanical_Count,
                SUM(CASE WHEN ClosedFaultType = 'Pneumatic' THEN TIMESTAMPDIFF(MINUTE, CreatedDateTime, ClosedDateTime) ELSE 0 END) AS Pneumatic_Count
                
             FROM 
                 tblwo_event 
               WHERE " . $whereClause." GROUP BY MachineNo";

            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            //$stmt = $conn->prepare("SELECT WorkOrderNo,CheckInUserDateTime,CheckOutUserDateTime FROM tblwo_allcheckinusers WHERE CheckInUser=:chkinusr");
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate2); 
            $stmt->bindParam(':edate', $strEndDate2); 
             
            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {   
                $ReturnData_ary[0][$i] = $row['MachineNo'];
                $ReturnData_ary[1][$i] = number_format($row['Electrical_Count'] / 60, 2); 
                $ReturnData_ary[2][$i] = number_format($row['Mechanical_Count'] / 60, 2); 
                $ReturnData_ary[3][$i] = number_format($row['Pneumatic_Count'] / 60, 2);  
                
                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = "Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn = null;
    }
    //------------- Table data load --------------------
    else if($strFuncType === "funGetData_Table") 
    {
        $strStarDate3       = $num[1];
        $strEndDate3        = $num[2];
        $strDepartment      = $num[3];
        $strCategory        = $num[4];
        $strStatus          = $num[5];

        $whereClause = "wo.WorkOrderCategory = 'BreakDown' AND State < 6 AND wo.ClosedDateTime IS NOT NULL AND DATE(wo.CreatedDateTime) BETWEEN :sdate AND :edate";

        if ($strDepartment !== "All") {
            $whereClause .= " AND wo.CreatedDepartment = '" . $strDepartment . "'";
        }
        if ($strCategory !== "All") {
            $whereClause .= " AND wo.Site = '" . $strCategory . "'";
        }          
        if ($strStatus !== "All") {
            $whereClause .= " AND IssueType  = '" . $strStatus . "'";          
        } 

        try 
        { 
            $sqlString = "
                SELECT             
                    wo.WorkOrderNo,
                    wo.Site,
                    wo.Location,
                    wo.CreatedDepartment,
                    wo.CreatedDateTime,
                    wo.CreatedUser,
                    wo.IssueType,
                    wo.RespondDateTime,
                    wo.ClosedDateTime,
                    wo.ClosedUser,
                    TIMESTAMPDIFF(MINUTE, wo.CreatedDateTime, wo.ClosedDateTime) as TotTimeDuration,
                    wo.VerifiedDateTime,
                    wo.VerifiedUser,
                    wo.ReOpenedDateTime,
                    wo.ReOpenedUser,
                    wo.WoDescription,
                    wo.WoStatus,
                    wo.Building,                    
                    (
                        SELECT GROUP_CONCAT(DISTINCT ua.EmpName SEPARATOR ', ') 
                        FROM tblwo_allocatedusers AS acu
                        LEFT JOIN tblusers_account AS ua ON acu.AllocatedUser = ua.EPF
                        WHERE acu.WorkOrderNo = wo.WorkOrderNo
                    ) AS AllocatedUsers,
                    (
                        SELECT GROUP_CONCAT(DISTINCT ua.EmpName SEPARATOR ', ') 
                        FROM tblwo_allcheckinusers AS ciu
                        LEFT JOIN tblusers_account AS ua ON ciu.CheckInUser = ua.EPF
                        WHERE ciu.WorkOrderNo = wo.WorkOrderNo
                    ) AS CheckInUsers
                FROM 
                    tblwo_event as wo
                WHERE " . $whereClause;

            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
            $stmt = $conn->prepare($sqlString);
            $stmt->bindParam(':sdate', $strStarDate3); 
            $stmt->bindParam(':edate', $strEndDate3);

            $stmt->execute();
            // set the resulting array to associative
            $stmt->setFetchMode(PDO::FETCH_ASSOC);        
            $result = $stmt->fetchAll();
            $i = 0;
            foreach($result as $row)
            {
                $ReturnData_ary[$i][0] = $row['WorkOrderNo'];
                $ReturnData_ary[$i][1] = $row['CreatedDateTime'];
                $ReturnData_ary[$i][2] = $row['CreatedDepartment']; 
                $ReturnData_ary[$i][3] = $row['Site']; 
                $ReturnData_ary[$i][4] = $row['Location']; 
                $ReturnData_ary[$i][5] = $row['IssueType']; 
                $ReturnData_ary[$i][6] = $row['WoDescription']; 
                $ReturnData_ary[$i][7] = $row['WoStatus'];     
                $ReturnData_ary[$i][8] = $row['CreatedUser'];           
                $ReturnData_ary[$i][9] = $row['RespondDateTime'];
                $ReturnData_ary[$i][10] = $row['AllocatedUsers'];                
                $ReturnData_ary[$i][11] = $row['CheckInUsers'];
                $ReturnData_ary[$i][12] = $row['ClosedDateTime'];                
                $ReturnData_ary[$i][13] = $row['ClosedUser'];                 
                $ReturnData_ary[$i][14] = number_format($row['TotTimeDuration']/ 60, 1) ;  
                $ReturnData_ary[$i][15] = $row['Building'];             
                $ReturnData_ary[$i][16] = $row['ReOpenedDateTime']; 
                $ReturnData_ary[$i][17] = $row['ReOpenedUser']; 
                $ReturnData_ary[$i][18] = $row['VerifiedDateTime']; 
                $ReturnData_ary[$i][19] = $row['VerifiedUser'];

                $i++;
            }  
            if($i === 0)    // No Data
            {
                $ReturnData_ary[0] = $strText;
                $Status_ary[0] = "false";
                $Status_ary[1] = "Data not found"; 
            }
            else
            {
                //$ReturnData_ary[0] = $strText;
                $Status_ary[0] = "true";
                $Status_ary[1] = "Data Available"; 
            } 
        } 
        catch(PDOException $ex) 
        {
            //$error =  "Error: " . $e->getMessage();
            $Status_ary[0] = "error";
            $Status_ary[1] = 'Error Msg: ' .$ex->getMessage();        
        }    
        $conn=null;
    }

    $data_ary['Status_Ary'] = $Status_ary;
    $data_ary['Data_Ary']   = $ReturnData_ary;
        
    //print json_encode($error);
    print json_encode($data_ary); 

?>
