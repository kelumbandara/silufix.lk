<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "user_management";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
    if (isset($_POST["deleteId"])) {
        // Process form data and delete a user
        $deleteId = $_POST["deleteId"];

        $stmt = $conn->prepare("DELETE FROM user_table WHERE ID = ?");
        $stmt->bind_param("i", $deleteId);

        if ($stmt->execute()) 
        {
            echo "User deleted successfully";
        } else 
        {
            echo "Error deleting user: " . $stmt->error;
        }

        $stmt->close();
    } else {
        // Process form data and insert a new user
        $epf = $_POST["epf"];
        $name = $_POST["name"];
        $age = $_POST["age"];
        $contact = $_POST["contact"];

        $stmt = $conn->prepare("INSERT INTO user_table (EPF, Name, Age, Contact) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $epf, $name, $age, $contact);

        if ($stmt->execute()) {
            echo "User added successfully";
        } else {
            echo "Error adding user: " . $stmt->error;
        }

        $stmt->close();
    }
} else {
    // Display Users Table
    $result = $conn->query("SELECT * FROM user_table");
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["ID"] . "</td>";
            echo "<td>" . $row["EPF"] . "</td>";
            echo "<td>" . $row["Name"] . "</td>";
            echo "<td>" . $row["Age"] . "</td>";
            echo "<td>" . $row["Contact"] . "</td>";
            echo "<td><button class='btn btn-warning btn-sm' onclick='editUser(" . $row["ID"] . ")'>Edit</button> <button class='btn btn-danger btn-sm' onclick='deleteUser(" . $row["ID"] . ")'>Delete</button></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No users found</td></tr>";
    }
}

// Close the database connection
$conn->close();
?>
