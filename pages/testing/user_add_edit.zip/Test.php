<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <title>User Management</title>
</head>
<body>

<div class="container mt-5">
    <h2>User Management</h2>

    <!-- Display Users Table -->
    <div class="mb-3">
        <h4>User List</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>EPF</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Contact</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="userTableBody">
                <!-- User data will be populated here dynamically -->
            </tbody>
        </table>
    </div>

    <!-- Add User Form -->
    <div>
        <h4>Add New User</h4>
        <form id="addUserForm">
            <div class="form-row">
                <div class="form-group col-md-2">
                    <label for="id">ID</label>
                    <input type="text" class="form-control" id="id" name="id" readonly>
                </div>
                <div class="form-group col-md-3">
                    <label for="epf">EPF</label>
                    <input type="text" class="form-control" id="epf" name="epf" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group col-md-2">
                    <label for="age">Age</label>
                    <input type="number" class="form-control" id="age" name="age" required>
                </div>
                <div class="form-group col-md-3">
                    <label for="contact">Contact</label>
                    <input type="tel" class="form-control" id="contact" name="contact" required>
                </div>
                <div class="form-group col-md-1">
                    <button type="submit" class="btn btn-primary" onclick="addUser()">Add</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Add jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        // Load user data on page load
        loadUsers();

        // Function to load user data
        function loadUsers() {
            $.ajax({
                type: "GET",
                url: "phppage.php", // Replace with your server-side script
                success: function (data) {
                    $("#userTableBody").html(data);
                }
            });
        }

        // Function to add a new user
        window.addUser = function ()
        {
            alert("add users");
            $.ajax({
                type: "POST",
                url: "phppage.php", // Replace with your server-side script
                data: $("#addUserForm").serialize(),
                success: function () 
                {
                    // Reload user data after adding a new user
                    loadUsers();
                    // Clear the form after submission
                    $("#addUserForm")[0].reset();
                }
            });
        };
        // Function to delete a user
        window.deleteUser = function (userId) {
            $.ajax({
                type: "POST",
                url: "phppage.php", // Replace with your server-side script
                data: { deleteId: userId },
                success: function () {
                    // Reload user data after deleting a user
                    loadUsers();
                }
            });
        };

        // Function to edit a user (just an example, you can customize it)
        window.editUser = function (userId) {
            // This is just an example, you can implement your own edit functionality
            alert("Edit user with ID: " + userId);
        };
        // Other functions for edit and delete can be added here

    });
</script>
</body>
</html>
